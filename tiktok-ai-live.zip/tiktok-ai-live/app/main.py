import os, asyncio, json
from collections import deque
from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from openai import AsyncOpenAI
from TikTokLive import TikTokLiveClient
from TikTokLive.events import CommentEvent, ConnectEvent, DisconnectEvent, GiftEvent, LikeEvent, RoomUserSeqEvent

load_dotenv()
app = FastAPI(title="TikTok LIVE AI")
app.mount("/static", StaticFiles(directory="static"), name="static")

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
MODEL = os.getenv("AI_MODEL", "gpt-4o-mini")
USERNAME = os.getenv("TIKTOK_USERNAME", "")
openai_client = AsyncOpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

clients = set()
messages = deque(maxlen=100)
state = {"connected": False, "viewer_count": 0, "likes": 0, "gifts": 0, "username": USERNAME}

async def broadcast(payload):
    dead = []
    text = json.dumps(payload, ensure_ascii=False)
    for ws in clients:
        try: await ws.send_text(text)
        except Exception: dead.append(ws)
    for ws in dead: clients.discard(ws)

async def ai_reply(comment: str, username: str):
    if not openai_client:
        return "AI belum aktif. Isi OPENAI_API_KEY di file .env."
    try:
        r = await openai_client.chat.completions.create(
            model=MODEL,
            temperature=0.7,
            max_tokens=80,
            messages=[
                {"role":"system","content":"Kamu adalah host AI TikTok LIVE berbahasa Indonesia. Jawab singkat, ramah, natural, maksimal 1-2 kalimat. Jangan mengaku sebagai manusia."},
                {"role":"user","content":f"Komentar dari @{username}: {comment}"}
            ]
        )
        return r.choices[0].message.content.strip()
    except Exception as e:
        return f"AI error: {type(e).__name__}"

async def handle_comment(event: CommentEvent):
    username = getattr(event.user, "unique_id", "viewer")
    comment = event.comment
    item = {"type":"comment","username":username,"text":comment}
    messages.append(item)
    await broadcast(item)
    reply = await ai_reply(comment, username)
    ai_item = {"type":"ai","username":"AI","text":reply}
    messages.append(ai_item)
    await broadcast(ai_item)

async def handle_events():
    if not USERNAME: return
    client = TikTokLiveClient(unique_id=USERNAME)
    @client.on(CommentEvent)
    async def on_comment(event): await handle_comment(event)
    @client.on(ConnectEvent)
    async def on_connect(event):
        state["connected"] = True
        await broadcast({"type":"status","connected":True})
    @client.on(DisconnectEvent)
    async def on_disconnect(event):
        state["connected"] = False
        await broadcast({"type":"status","connected":False})
    @client.on(LikeEvent)
    async def on_like(event):
        state["likes"] += getattr(event, "like_count", 1) or 1
        await broadcast({"type":"stats",**state})
    @client.on(GiftEvent)
    async def on_gift(event):
        state["gifts"] += 1
        await broadcast({"type":"stats",**state})
    @client.on(RoomUserSeqEvent)
    async def on_users(event):
        state["viewer_count"] = getattr(event, "total_user", state["viewer_count"]) or state["viewer_count"]
        await broadcast({"type":"stats",**state})
    while True:
        try:
            await client.connect()
            break
        except Exception as e:
            await broadcast({"type":"error","message":f"TikTok connection: {type(e).__name__}"})
            await asyncio.sleep(10)

@app.on_event("startup")
async def startup():
    if USERNAME:
        asyncio.create_task(handle_events())

@app.get("/")
async def index(): return FileResponse("static/index.html")

@app.get("/api/state")
async def api_state(): return {**state,"messages":list(messages)}

@app.websocket("/ws")
async def websocket(ws: WebSocket):
    await ws.accept(); clients.add(ws)
    try:
        await ws.send_text(json.dumps({"type":"init","state":state,"messages":list(messages)}, ensure_ascii=False))
        while True: await ws.receive_text()
    except WebSocketDisconnect: clients.discard(ws)
