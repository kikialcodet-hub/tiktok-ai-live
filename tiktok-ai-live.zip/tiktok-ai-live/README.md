# TikTok LIVE AI — real-time starter

Ini bukan dashboard dummy. Backend memakai `TikTokLive` untuk menerima event LIVE seperti komentar, gift, like, dan jumlah viewer. Library tersebut merupakan integrasi komunitas, bukan API resmi TikTok.

## Jalankan
1. Python 3.10+.
2. `python -m venv .venv`
3. Aktifkan venv.
4. `pip install -r requirements.txt`
5. Salin `.env.example` menjadi `.env`.
6. Isi `OPENAI_API_KEY` dan `TIKTOK_USERNAME` (tanpa @).
7. `uvicorn app.main:app --host 0.0.0.0 --port 8000`
8. Buka `http://localhost:8000`.

## Catatan koneksi TikTok
TikTok saat ini tidak menyediakan API publik resmi untuk membaca event livestream secara umum. Karena itu konektor di proyek ini memakai library komunitas. Penggunaan harus mengikuti aturan TikTok dan dapat berubah jika TikTok mengubah sistem LIVE.

## AI
Respons komentar dibuat oleh OpenAI API. Jangan menaruh API key di frontend.

## TTS
Respons AI dibacakan memakai SpeechSynthesis browser. Untuk voice server-side/OBS, ganti bagian TTS dengan provider suara pilihanmu.
